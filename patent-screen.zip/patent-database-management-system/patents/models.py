from django.db import models
import pymysql
class PatentBiomass(models.Model):      #生物质能
    public_num = models.CharField(primary_key=True, max_length=32)
    status = models.TextField(blank=True, null=True)
    title = models.TextField(blank=True, null=True)
    type = models.TextField(blank=True, null=True)
    abstract = models.TextField(blank=True, null=True)
    appli_num = models.TextField(blank=True, null=True)
    appli_date = models.TextField(blank=True, null=True)
    public_date = models.TextField(blank=True, null=True)
    applicant = models.TextField(blank=True, null=True)
    applicant_address = models.TextField(blank=True, null=True)
    patentee = models.TextField(blank=True, null=True)
    patentee_address = models.TextField(blank=True, null=True)
    inventor = models.TextField(blank=True, null=True)
    agent = models.TextField(blank=True, null=True)
    ipc = models.TextField(db_column='IPC', blank=True, null=True)  # Field name made lowercase.
    cpc = models.TextField(db_column='CPC', blank=True, null=True)  # Field name made lowercase.
    nec = models.TextField(db_column='NEC', blank=True, null=True)  # Field name made lowercase.
    latest_legal_status = models.TextField(blank=True, null=True)
    patent_details = models.TextField(blank=True, null=True)





class PatentHydrogen(models.Model):     #氢能
    public_num = models.CharField(primary_key=True, max_length=32)
    status = models.TextField(blank=True, null=True)
    title = models.TextField(blank=True, null=True)
    type = models.TextField(blank=True, null=True)
    abstract = models.TextField(blank=True, null=True)
    appli_num = models.TextField(blank=True, null=True)
    appli_date = models.TextField(blank=True, null=True)
    public_date = models.TextField(blank=True, null=True)
    applicant = models.TextField(blank=True, null=True)
    applicant_address = models.TextField(blank=True, null=True)
    patentee = models.TextField(blank=True, null=True)
    patentee_address = models.TextField(blank=True, null=True)
    inventor = models.TextField(blank=True, null=True)
    agent = models.TextField(blank=True, null=True)
    ipc = models.TextField(db_column='IPC', blank=True, null=True)  # Field name made lowercase.
    cpc = models.TextField(db_column='CPC', blank=True, null=True)  # Field name made lowercase.
    nec = models.TextField(db_column='NEC', blank=True, null=True)  # Field name made lowercase.
    latest_legal_status = models.TextField(blank=True, null=True)
    patent_details = models.TextField(blank=True, null=True)



class PatentLilon(models.Model):        #智能电网
    public_num = models.CharField(primary_key=True, max_length=32)
    status = models.TextField(blank=True, null=True)
    title = models.TextField(blank=True, null=True)
    type = models.TextField(blank=True, null=True)
    abstract = models.TextField(blank=True, null=True)
    appli_num = models.TextField(blank=True, null=True)
    appli_date = models.TextField(blank=True, null=True)
    public_date = models.TextField(blank=True, null=True)
    applicant = models.TextField(blank=True, null=True)
    applicant_address = models.TextField(blank=True, null=True)
    patentee = models.TextField(blank=True, null=True)
    patentee_address = models.TextField(blank=True, null=True)
    inventor = models.TextField(blank=True, null=True)
    agent = models.TextField(blank=True, null=True)
    ipc = models.TextField(db_column='IPC', blank=True, null=True)  # Field name made lowercase.
    cpc = models.TextField(db_column='CPC', blank=True, null=True)  # Field name made lowercase.
    nec = models.TextField(db_column='NEC', blank=True, null=True)  # Field name made lowercase.
    latest_legal_status = models.TextField(blank=True, null=True)
    patent_details = models.TextField(blank=True, null=True)




class PatentSolar(models.Model):        #太阳能
    public_num = models.CharField(primary_key=True, max_length=32)
    status = models.TextField(blank=True, null=True)
    title = models.TextField(blank=True, null=True)
    type = models.TextField(blank=True, null=True)
    abstract = models.TextField(blank=True, null=True)
    appli_num = models.TextField(blank=True, null=True)
    appli_date = models.TextField(blank=True, null=True)
    public_date = models.TextField(blank=True, null=True)
    applicant = models.TextField(blank=True, null=True)
    applicant_address = models.TextField(blank=True, null=True)
    patentee = models.TextField(blank=True, null=True)
    patentee_address = models.TextField(blank=True, null=True)
    inventor = models.TextField(blank=True, null=True)
    agent = models.TextField(blank=True, null=True)
    ipc = models.TextField(db_column='IPC', blank=True, null=True)  # Field name made lowercase.
    cpc = models.TextField(db_column='CPC', blank=True, null=True)  # Field name made lowercase.
    nec = models.TextField(db_column='NEC', blank=True, null=True)  # Field name made lowercase.
    latest_legal_status = models.TextField(blank=True, null=True)
    patent_details = models.TextField(blank=True, null=True)



class PatentWind(models.Model):     #风能
    public_num = models.CharField(primary_key=True, max_length=32)
    status = models.TextField(blank=True, null=True)
    title = models.TextField(blank=True, null=True)
    type = models.TextField(blank=True, null=True)
    abstract = models.TextField(blank=True, null=True)
    appli_num = models.TextField(blank=True, null=True)
    appli_date = models.TextField(blank=True, null=True)
    public_date = models.TextField(blank=True, null=True)
    applicant = models.TextField(blank=True, null=True)
    applicant_address = models.TextField(blank=True, null=True)
    patentee = models.TextField(blank=True, null=True)
    patentee_address = models.TextField(blank=True, null=True)
    inventor = models.TextField(blank=True, null=True)
    agent = models.TextField(blank=True, null=True)
    ipc = models.TextField(db_column='IPC', blank=True, null=True)  # Field name made lowercase.
    cpc = models.TextField(db_column='CPC', blank=True, null=True)  # Field name made lowercase.
    nec = models.TextField(db_column='NEC', blank=True, null=True)  # Field name made lowercase.
    latest_legal_status = models.TextField(blank=True, null=True)
    patent_details = models.TextField(blank=True, null=True)


class Collection(models.Model):
    name = models.CharField(max_length=32)
    entry_biomass = models.ManyToManyField(PatentBiomass)
    entry_hydrogen = models.ManyToManyField(PatentHydrogen)
    entry_lilon = models.ManyToManyField(PatentLilon)
    entry_solar = models.ManyToManyField(PatentSolar)
    entry_wind = models.ManyToManyField(PatentWind)

class Account(models.Model):
    username = models.CharField(max_length=32)
    password = models.CharField(max_length=128)
    collect = models.ManyToManyField(Collection)
