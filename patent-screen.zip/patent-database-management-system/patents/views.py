from itertools import chain

from django.db.models import Count
from django.db.models.query import QuerySet
from django.http import JsonResponse, HttpResponse
from django.core import serializers
from patents import models

import pymysql
def returnData(data, page, size, code, msg):
    page = int(page)
    size = int(size)
    if isinstance(data, QuerySet):
        data = serializers.serialize("json", data[(page - 1) * size: page * size])
    else:
        data = data[(page - 1) * size: page * size]
    result = JsonResponse({"code": code, "data": data, "msg": msg}, json_dumps_params={'ensure_ascii': False})
    # 设置响应头，允许跨域请求
    result['Access-Control-Allow-origin'] = "http://localhost:8080"
    result['Access-Control-Allow-Credentials'] = "true"
    return result


def returnData1(data, code, msg):
    if isinstance(data, QuerySet):
        data = serializers.serialize("json", data)
    result = JsonResponse({"code": code, "data": data, "msg": msg}, json_dumps_params={'ensure_ascii': False})
    result['Access-Control-Allow-origin'] = "http://localhost:8080"
    result['Access-Control-Allow-Credentials'] = "true"
    return result


def returnData2(data, code, msg):
    if isinstance(data, QuerySet):
        data = serializers.serialize("json", data)
    result = JsonResponse({"code": code, "data": data, "msg": msg}, json_dumps_params={'ensure_ascii': False})
    result['Access-Control-Allow-origin'] = "*"
    result['Access-Control-Allow-Credentials'] = "true"
    return result


def index(request):
    return HttpResponse("欢迎使用")


# 返回专利数量
def count(request):  # 返回专利数据条目
    data_count = 0
    data_count += models.PatentBiomass.objects.all().count()
    data_count += models.PatentWind.objects.all().count()
    data_count += models.PatentSolar.objects.all().count()
    data_count += models.PatentHydrogen.objects.all().count()
    data_count += models.PatentLilon.objects.all().count()

    return returnData1(data_count, 200, "OK")

def count1(request):  # 返回专利数据条目
    data_count = 0
    data_count += models.PatentBiomass.objects.all().count()
    data_count += models.PatentWind.objects.all().count()
    data_count += models.PatentSolar.objects.all().count()
    data_count += models.PatentHydrogen.objects.all().count()
    data_count += models.PatentLilon.objects.all().count()

    return returnData2(data_count, 200, "OK")

def count_type(request):
    biomass_count = models.PatentBiomass.objects.all().count()
    hydrogen_count = models.PatentHydrogen.objects.all().count()
    lilon_count = models.PatentLilon.objects.all().count()
    solar_count = models.PatentSolar.objects.all().count()
    wind_count = models.PatentWind.objects.all().count()

    return returnData2({"biomass": biomass_count, "hydrogen": hydrogen_count, "lilon": lilon_count,
                        "solar": solar_count, "wind": wind_count}, 200, "OK")


# 展示数据相关功能
def display_all(request):  # 展示全部数据
    page = request.GET.get("page")
    size = request.GET.get("size")
    data = models.PatentBiomass.objects.all()
    data = data.union(models.PatentHydrogen.objects.all())
    data = data.union(models.PatentLilon.objects.all())
    data = data.union(models.PatentSolar.objects.all())
    data = data.union(models.PatentWind.objects.all())

    return returnData(data, page, size, 200, len(data))


def display_biomass(request):  # 展示生物质能数据
    page = request.GET.get("page")
    size = request.GET.get("size")
    data = models.PatentBiomass.objects.all()

    return returnData(data, page, size, 200, "OK")


def display_hydrogen(request):  # 展示氢能数据
    page = request.GET.get("page")
    size = request.GET.get("size")
    data = models.PatentHydrogen.objects.all()

    return returnData(data, page, size, 200, "OK")


def display_lilon(request):  # 展示智能电网数据
    page = request.GET.get("page")
    size = request.GET.get("size")
    data = models.PatentLilon.objects.all()

    return returnData(data, page, size, 200, "OK")


def display_solar(request):  # 展示太阳能数据
    page = request.GET.get("page")
    size = request.GET.get("size")
    data = models.PatentSolar.objects.all()

    return returnData(data, page, size, 200, "OK")


def display_wind(request):  # 展示风能数据
    page = request.GET.get("page")
    size = request.GET.get("size")
    data = models.PatentWind.objects.all()

    return returnData(data, page, size, 200, "OK")


# 检索相关功能
def search_all(request):
    if request.method == "POST":
        keyword = request.POST.get("kw")
        field = request.POST.get("field", "title")
        page = request.POST.get("page")
        size = request.POST.get("size")
        query_dict = {field + "__contains": keyword}

        data = models.PatentBiomass.objects.filter(**query_dict)
        data = data.union(models.PatentHydrogen.objects.filter(**query_dict))
        data = data.union(models.PatentLilon.objects.filter(**query_dict))
        data = data.union(models.PatentSolar.objects.filter(**query_dict))
        data = data.union(models.PatentWind.objects.filter(**query_dict))

        return returnData(data, page, size, 200, len(data))
    else:
        return returnData1("", 500, "ERROR")


def search_biomass(request):
    if request.method == "POST":
        keyword = request.POST.get("kw")
        field = request.POST.get("field", "title")
        page = request.POST.get("page")
        size = request.POST.get("size")
        query_dict = {field + "__contains": keyword}

        data = models.PatentBiomass.objects.filter(**query_dict)
        return returnData(data, page, size, 200, len(data))
    else:
        return returnData1("", 500, "ERROR")


def search_hydrogen(request):
    if request.method == "POST":
        keyword = request.POST.get("kw")
        field = request.POST.get("field", "title")
        page = request.POST.get("page")
        size = request.POST.get("size")
        query_dict = {field + "__contains": keyword}

        data = models.PatentHydrogen.objects.filter(**query_dict)
        return returnData(data, page, size, 200, len(data))
    else:
        return returnData1("", 500, "ERROR")


def search_lilon(request):
    if request.method == "POST":
        keyword = request.POST.get("kw")
        field = request.POST.get("field", "title")
        page = request.POST.get("page")
        size = request.POST.get("size")
        query_dict = {field + "__contains": keyword}

        data = models.PatentLilon.objects.filter(**query_dict)
        return returnData(data, page, size, 200, len(data))
    else:
        return returnData1("", 500, "ERROR")


def search_solar(request):
    if request.method == "POST":
        keyword = request.POST.get("kw")
        field = request.POST.get("field", "title")
        page = request.POST.get("page")
        size = request.POST.get("size")
        query_dict = {field + "__contains": keyword}

        data = models.PatentSolar.objects.filter(**query_dict)
        return returnData(data, page, size, 200, len(data))
    else:
        return returnData1("", 500, "ERROR")


def search_wind(request):
    if request.method == "POST":
        keyword = request.POST.get("kw")
        field = request.POST.get("field", "title")
        page = request.POST.get("page")
        size = request.POST.get("size")
        query_dict = {field + "__contains": keyword}

        data = models.PatentWind.objects.filter(**query_dict)
        return returnData(data, page, size, 200, len(data))
    else:
        return returnData1("", 500, "ERROR")


# 登录注册相关功能
def register(request):
    if request.session.get("is_login", False):
        return returnData1("", 501, "用户重复登录")
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")
        print(username, password)
        if models.Account.objects.filter(username=username).first():
            return returnData1("", 502, "用户已存在")
        else:
            favorite = models.Collection.objects.create(name="默认收藏夹")
            user = models.Account.objects.create(username=username, password=password)
            user.collect.add(favorite)
            request.session['is_login'] = True
            request.session['user_id'] = user.id
            request.session['username'] = user.username
            return returnData1("", 201, "注册成功")
    else:
        return returnData1("", 500, "ERROR")


def login(request):
    if request.session.get("is_login", False):
        return returnData1("", 501, "用户重复登录")
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")
        if username and password:
            user = models.Account.objects.filter(username=username, password=password).first()
            if user:
                request.session['is_login'] = True
                request.session['user_id'] = user.id
                request.session['username'] = user.username
                return returnData1("", 202, "登录成功")
            else:
                return returnData1("", 503, "用户名或密码错误")
        else:
            return returnData1("", 504, "用户信息未找到")
    else:
        return returnData1("", 500, "ERROR")


def logout(request):
    if request.session.get("is_login", False):
        request.session.flush()
        return returnData1("", 203, "登出成功")
    else:
        return returnData1("", 505, "用户未登录")


def is_login(request):
    if request.session.get("is_login", False):
        return returnData1(True, 200, "OK")
    else:
        return returnData1(False, 500, "ERROR")


def username(request):
    if request.session.get("is_login", False):
        return returnData1(request.session.get('username', 'error'), 200, "OK")
    else:
        return returnData1('none', 500, "ERROR")


# 收藏相关功能
def collection_display(request):
    if request.session.get("is_login", False):
        page = request.GET.get("page")
        size = request.GET.get("size")
        favor_name = request.GET.get("name")  # 获取当前收藏夹名
        user_id = request.session.get("user_id", 0)
        user = models.Account.objects.filter(id=user_id).first()  # 获取当前用户
        favorite = user.collect.all().filter(name=favor_name).first()  # 获取当前收藏夹
        if not favorite:
            return returnData1("", 508, "收藏夹不存在")

        data = favorite.entry_biomass.all()  # 从五张表里检索数据
        data = data.union(favorite.entry_hydrogen.all())
        data = data.union(favorite.entry_lilon.all())
        data = data.union(favorite.entry_solar.all())
        data = data.union(favorite.entry_wind.all())

        return returnData(data, page, size, 200, "OK")
    else:
        return returnData1("", 505, "用户未登录")


def collection_add(request):
    if request.session.get("is_login", False):
        favor_name = request.POST.get("name")
        favor_entry = request.POST.get("public_num")
        user_id = request.session.get("user_id", 0)
        user = models.Account.objects.filter(id=user_id).first()
        favorite = user.collect.all().filter(name=favor_name).first()
        if not favorite:
            return returnData1("", 508, "收藏夹不存在")

        entry1 = models.PatentBiomass.objects.filter(public_num=favor_entry).first()  # 五张表里依次查询
        entry2 = models.PatentHydrogen.objects.filter(public_num=favor_entry).first()
        entry3 = models.PatentLilon.objects.filter(public_num=favor_entry).first()
        entry4 = models.PatentSolar.objects.filter(public_num=favor_entry).first()
        entry5 = models.PatentWind.objects.filter(public_num=favor_entry).first()

        if entry1 and not favorite.entry_biomass.filter(public_num=favor_entry).exists():
            favorite.entry_biomass.add(entry1)
        elif entry2 and not favorite.entry_hydrogen.filter(public_num=favor_entry).exists():
            favorite.entry_hydrogen.add(entry2)
        elif entry3 and not favorite.entry_lilon.filter(public_num=favor_entry).exists():
            favorite.entry_lilon.add(entry3)
        elif entry4 and not favorite.entry_solar.filter(public_num=favor_entry).exists():
            favorite.entry_solar.add(entry4)
        elif entry5 and not favorite.entry_wind.filter(public_num=favor_entry).exists():
            favorite.entry_wind.add(entry5)
        else:
            return returnData1("", 506, "重复收藏")
        return returnData1("", 200, "OK")
    else:
        return returnData1("", 505, "用户未登录")


def collection_delete(request):
    if request.session.get("is_login", False):
        favor_name = request.POST.get("name")
        favor_entry = request.POST.get("public_num")
        user_id = request.session.get("user_id", 0)
        user = models.Account.objects.filter(id=user_id).first()
        favorite = user.collect.all().filter(name=favor_name).first()
        if not favorite:
            return returnData1("", 508, "收藏夹不存在")

        if favorite.entry_biomass.filter(public_num=favor_entry).exists():
            favorite.entry_biomass.remove(favor_entry)
        elif favorite.entry_hydrogen.filter(public_num=favor_entry).exists():
            favorite.entry_hydrogen.remove(favor_entry)
        elif favorite.entry_lilon.filter(public_num=favor_entry).exists():
            favorite.entry_lilon.remove(favor_entry)
        elif favorite.entry_solar.filter(public_num=favor_entry).exists():
            favorite.entry_solar.remove(favor_entry)
        elif favorite.entry_wind.filter(public_num=favor_entry).exists():
            favorite.entry_wind.remove(favor_entry)
        else:
            return returnData1("", 500, "ERROR")
    else:
        return returnData1("", 505, "用户未登录")


def collection_search(request):
    keyword = request.POST.get("kw")
    field = request.POST.get("field", "title")
    page = request.POST.get("page")
    size = request.POST.get("size")
    query_dict = {field + "__contains": keyword}


def favorites_display(request):
    if request.session.get("is_login", False):
        user_id = request.session.get("user_id", 0)
        user = models.Account.objects.filter(id=user_id).first()
        data = list(user.collect.values_list("name"))
        return returnData1(data, 200, "OK")
    else:
        return returnData1("", 505, "用户未登录")


def favorites_add(request):
    if request.session.get("is_login", False):
        favor_name = request.POST.get("name")
        user_id = request.session.get("user_id", 0)
        user = models.Account.objects.filter(id=user_id).first()
        if user.collect.all().filter(name=favor_name).exists():
            return returnData1("", 507, "收藏夹已存在")
        favorite = models.Collection.objects.create(name=favor_name)
        user.collect.add(favorite)
        return returnData1("", 204, "收藏夹创建成功")
    else:
        return returnData1("", 505, "用户未登录")


def favorites_delete(request):
    if request.session.get("is_login", False):
        favor_name = request.POST.get("name")
        user_id = request.session.get("user_id", 0)
        user = models.Account.objects.filter(id=user_id).first()
        user.collect.all().filter(name=favor_name).delete()
        return returnData1("", 200, "OK")
    else:
        return returnData1("", 505, "用户未登录")


# 数据大屏相关
def get_region(request):
    region_name = "河北,山西,内蒙古,辽宁,吉林,黑龙江,江苏,浙江,安徽,福建,江西,山东,河南,湖北,湖南,广东," \
                  "广西,海南,四川,贵州,云南,西藏,陕西,甘肃,青海,宁夏,新疆,北京,天津,上海,重庆,台湾"
    data_list = []

    for name in region_name.split(","):
        c1 = models.PatentBiomass.objects.filter(applicant_address__contains=name).count()
        c2 = models.PatentHydrogen.objects.filter(applicant_address__contains=name).count()
        c3 = models.PatentLilon.objects.filter(applicant_address__contains=name).count()
        c4 = models.PatentSolar.objects.filter(applicant_address__contains=name).count()
        c5 = models.PatentWind.objects.filter(applicant_address__contains=name).count()
        mydict = {name: [c1, c2, c3, c4, c5]}
        data_list.append(mydict)

    return returnData2(data_list, 200, "OK")


def get_type(request):
    data_list = []
    mylist = [0, 0, 0, 0]
    i = 0
    for data in models.PatentBiomass.objects.values("type").annotate(count=Count('*')):
        mylist[i] = data['count']
        i = i + 1
    data_list.append({"生物质能": mylist})

    mylist = [0, 0, 0, 0]
    i = 0
    for data in models.PatentHydrogen.objects.values("type").annotate(count=Count('*')):
        mylist[i] = data['count']
        i = i + 1
    data_list.append({"氢能": mylist})

    mylist = [0, 0, 0, 0]
    i = 0
    for data in models.PatentLilon.objects.values("type").annotate(count=Count('*')):
        mylist[i] = data['count']
        i = i + 1
    data_list.append({"锂离子电池": mylist})

    mylist = [0, 0, 0, 0]
    i = 0
    for data in models.PatentSolar.objects.values("type").annotate(count=Count('*')):
        mylist[i] = data['count']
        i = i + 1
    data_list.append({"太阳能": mylist})

    mylist = [0, 0, 0, 0]
    i = 0
    for data in models.PatentWind.objects.values("type").annotate(count=Count('*')):
        mylist[i] = data['count']
        i = i + 1
    data_list.append({"风能": mylist})
    return returnData2(data_list, 200, "OK")


def get_year(request):
    def search_data(year):
        c1 = models.PatentBiomass.objects.filter(public_date__contains=year).count()
        c2 = models.PatentHydrogen.objects.filter(public_date__contains=year).count()
        c3 = models.PatentLilon.objects.filter(public_date__contains=year).count()
        c4 = models.PatentSolar.objects.filter(public_date__contains=year).count()
        c5 = models.PatentWind.objects.filter(public_date__contains=year).count()
        return c1 + c2 + c3 + c4 + c5

    mydict = {'date': ['2000', '2001', '2002', '2003', '2004', '2005', '2006', '2007', '2008', '2009', '2010', '2021',
                       '2012', '2013', '2014', '2015', '2016', '2017', '2018', '2019', '2020', '2021', '2022', '2023'],
              'data': []}

    for year in mydict['date']:
        mydict['data'].append(search_data(year))

    return returnData2(mydict, 200, "OK")


def get_status(request):
    def search_data(status):
        c1 = models.PatentBiomass.objects.filter(status=status).count()
        c2 = models.PatentHydrogen.objects.filter(status=status).count()
        c3 = models.PatentLilon.objects.filter(status=status).count()
        c4 = models.PatentSolar.objects.filter(status=status).count()
        c5 = models.PatentWind.objects.filter(status=status).count()
        return c1 + c2 + c3 + c4 + c5

    mydict = {"有效": search_data("有效"), "失效": search_data("失效"), "审查中": search_data("审查中")}

    return returnData2(mydict, 200, "OK")

#
def get_applicant(request):
    MAX_COUNT = 5
    data_list = []
    mydict = {}
    data1 = models.PatentBiomass.objects.values("applicant").annotate(count=Count('*')).order_by('-count')
    data2 = models.PatentHydrogen.objects.values("applicant").annotate(count=Count('*')).order_by('-count')
    data3 = models.PatentLilon.objects.values("applicant").annotate(count=Count('*')).order_by('-count')
    data4 = models.PatentSolar.objects.values("applicant").annotate(count=Count('*')).order_by('-count')
    data5 = models.PatentWind.objects.values("applicant").annotate(count=Count('*')).order_by('-count')

    for obj, i in zip(data1, range(MAX_COUNT)):
        mydict[obj['applicant']] = obj['count']
    data_list.append(mydict)
    mydict = {}

    for obj, i in zip(data2, range(MAX_COUNT)):
        mydict[obj['applicant']] = obj['count']
    data_list.append(mydict)
    mydict = {}

    for obj, i in zip(data3, range(MAX_COUNT)):
        mydict[obj['applicant']] = obj['count']
    data_list.append(mydict)
    mydict = {}

    for obj, i in zip(data4, range(MAX_COUNT)):
        mydict[obj['applicant']] = obj['count']
    data_list.append(mydict)
    mydict = {}

    for obj, i in zip(data5, range(MAX_COUNT)):
        mydict[obj['applicant']] = obj['count']
    data_list.append(mydict)
    mydict = {}

    return returnData2(data_list, 200, "OK")

def get_applicant1(request):
    def search_data(name):
        c1 = models.PatentBiomass.objects.filter(applicant_address__contains=name).values("applicant_address").distinct().count()
        c2 = models.PatentHydrogen.objects.filter(applicant_address__contains=name).values("applicant_address").distinct().count()
        c3 = models.PatentLilon.objects.filter(applicant_address__contains=name).values("applicant_address").distinct().count()
        c4 = models.PatentSolar.objects.filter(applicant_address__contains=name).values("applicant_address").distinct().count()
        c5 = models.PatentWind.objects.filter(applicant_address__contains=name).values("applicant_address").distinct().count()
        return c1 + c2 + c3 + c4 + c5

    mydict = {"天津": search_data("天津"), "北京": search_data("北京")}

    return returnData2(mydict, 200, "OK")