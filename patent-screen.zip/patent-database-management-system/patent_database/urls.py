"""
URL configuration for patent_database project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from patents import views

urlpatterns = [
    # path("admin/", admin.site.urls),
    path("index/", views.index),
    path("count/", views.count),
    path("count1/", views.count1),
    path("count/type/", views.count_type),

    # 展示数据相关
    path("display/all/", views.display_all),
    path("display/biomass/", views.display_biomass),
    path("display/hydrogen/", views.display_hydrogen),
    path("display/lilon/", views.display_lilon),
    path("display/solar/", views.display_solar),
    path("display/wind/", views.display_wind),

    # 检索数据相关
    path("search/all/", views.search_all),
    path("search/biomass/", views.search_biomass),
    path("search/hydrogen/", views.search_hydrogen),
    path("search/lilon/", views.search_lilon),
    path("search/solar/", views.display_solar),
    path("search/wind/", views.display_wind),

    # 注册登录相关
    path("register/", views.register),
    path("login/", views.login),
    path("logout/", views.logout),
    path("is_login/", views.is_login),
    path("username/", views.username),

    # 用户收藏相关
    path("collection/display/", views.collection_display),
    path("collection/add/", views.collection_add),
    path("collection/delete/", views.collection_delete),
    path("collection/search/", views.collection_search),
    path("favorites/display/", views.favorites_display),
    path("favorites/add/", views.favorites_add),
    path("favorites/delete/", views.favorites_delete),

    # 数据大屏相关
    path("get/region/", views.get_region),  # 获取各地区专利申请数量
    path("get/type/", views.get_type),  # 获取五种分类的专利状态数量
    path("get/year/", views.get_year),  # 获取各个年份的专利申请数量
    path("get/status/", views.get_status),  # 获取有效、失效、审查中的专利数量
    path("get/applicant/", views.get_applicant),  # 获取五种分类申请人前五名
    path("get/applicant/num/", views.get_applicant1),  # 获取天津和北京的申请人数量
]
